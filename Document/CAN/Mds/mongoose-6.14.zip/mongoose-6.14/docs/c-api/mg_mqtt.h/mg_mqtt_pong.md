---
title: "mg_mqtt_pong()"
decl_name: "mg_mqtt_pong"
symbol_kind: "func"
signature: |
  void mg_mqtt_pong(struct mg_connection *nc);
---

Sends a PINGRESP command. 

