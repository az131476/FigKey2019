---
title: "mbuf_clear()"
decl_name: "mbuf_clear"
symbol_kind: "func"
signature: |
  void mbuf_clear(struct mbuf *);
---

Removes all the data from mbuf (if any). 

