Please download the [nRF5 IoT SDK](http://developer.nordicsemi.com/nRF5_IoT_SDK/)
and unpack it into this directory, so that it contains `components`,
`external`, etc.
