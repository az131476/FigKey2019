---
title: Mongoose - a networking library
color: '#1D6482'
repo: https://github.com/cesanta/mongoose
items:
  - { name: overview }
  - { name: http }
  - { name: mqtt }
  - { name: dns }
  - { name: coap }
  - { name: dns_resolver }
  - { name: core }
---
