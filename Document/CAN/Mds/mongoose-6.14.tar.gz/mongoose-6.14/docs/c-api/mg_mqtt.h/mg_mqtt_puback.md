---
title: "mg_mqtt_puback()"
decl_name: "mg_mqtt_puback"
symbol_kind: "func"
signature: |
  void mg_mqtt_puback(struct mg_connection *nc, uint16_t message_id);
---

Sends a PUBACK command with a given `message_id`. 

